This folder contains the code for the display for the workflow and results of the Breast Cancer Detection project. We had developed only the front-end just to present this to the exam invigilators.
The webpage is written using HTML, CSS, and JavaScript.
